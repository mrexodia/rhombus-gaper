const a = 'rhombus{typosquatting_';
const b = 'the_build_';
const c = 'pipeline}';
console.log(Buffer.from(a + b + c).toString('base64'));
